import 'package:flutter/material.dart';

class AppImages {
  static const appspalshImg = "assets/images/splashimg.png";
  static const plus = "assets/images/plus.png";
  static const cog = "assets/images/cog.png";
  static const search = "assets/images/search.png";
  static const box = "assets/images/box.png";
}
