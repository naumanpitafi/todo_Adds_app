import 'package:hive/hive.dart';

class ThemeFileModel {
  String? themeStatus;

  ThemeFileModel({
    required this.themeStatus,
  });
}
